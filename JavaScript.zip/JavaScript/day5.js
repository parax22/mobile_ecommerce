// function validate(code)
// {
//     var validate = !isNaN(code) && code.toString().length == 6
//     console.log(validate)
// }

// validate(111111)
// validate("012345")
// validate("XYZXYZ")
// console.log(typeof("81000"))

console.log(navigator.cookieEnabled)


