 // Asynchoronous -> use async/awailt -> instead of promise chaining


 // -- Number Formating --

 //toFixed -> decimal Values
//  let a = 22.27814787
//  console.log(a.toFixed(0))

//toPrecision -> decimal Values including whole number
// console.log(a.toPrecision(4))

//toExponential -> to convert into Exponential form
// let b = 59.9999998
// console.log(b.toExponential(7))

// let str = "Param" //datatype is assumbed by js ->implicitly ->internaly
// let str1 = String("Param")//datatype is set by set by user ->explicitly ->externaly
//valueOf() -> method converts object into premitive data type
// let n = str.typeOf()
// console.log(n)

// let num = 20
// let num1 = new Number(30)
// console.log(num1.valueOf())

// -- Math Method --

// let x = -185.454
// console.log(Math.floor(x)) //Math.floor -> lowest Possible value
// console.log(Math.ceil(x)) //Math.ceil -> highest Possible value
// console.log(Math.round(x)) //Math.round -> round the value, if => 5 then +1
// console.log(Math.trunc(x)) //Math.trunc -> ignores your decimal Values
// console.log(Math.floor(Math.random()*50))
// console.log(Math.abs(-18)) //absolute value of -ve to convert into +ve value
// console.log(Math.E)// Euler Number
// console.log(Math.PI)
// console.log(Math.LN10)//Logarithm of 10
// console.log(Math.LN2)//Logarithm of 2
// console.log(Math.LOG10E)//Logarithm of 10 Euler Number
// console.log(Math.LOG2E)//Logarithm of 2 Euler Number`

// Number Properties
// console.log(Number.MAX_VALUE)// Maximum value that can be Handled by javascript
// console.log(Number.MIN_VALUE*Math.pow(2,10))// Minimum value that can be Handled by  javascript

// console.log(1/0)
// console.log(-1/0)

// -- loops --//

// for(let i=0 ; i<=10 ; i++)
// {
//     if(i==5)
//     {
//         continue //continue -> skips the iteration
//     }
//     console.log(i)
// }

let i=0
do
{
    console.log(i) //do while -> first executes the statment and then checks for the condition //loops will run atleast once -> it fails the condition
    i++
}
while(i<=5)