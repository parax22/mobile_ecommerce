// console.log(typeof(undefined)) // type of undifined is undifiend

// console.log(typeof(null)) // type of null in JavaScript is Object

// let t = "123"
// console.log(t.padStart(5,"0"))
// console.log(t.padEnd(7,"abc"))
// console.log(t.indexOf("3"))

// let x = "   abc   "
// console.log(x.trim())
// console.log(x.trimStart())
// console.log(x.trimEnd())


// let a = "Param"
// console.log(a.indexOf())
// console.log(a.indexOf("a ") + " " + a.lastIndexOf("a"))
// console.log(a.search("a"))
// let t = "PaghadarParam"
// console.log(t.search("ara")) //search and indexof exactly same purpose of use -> search -> searching & indexof -> retriving index of element

// console.log(t.split()) //String Array
// console.log(t.split("")) //containg each and every char in array element

// let z = "Python"
// console.log(z.includes('o'))// Search and give back boolean Response

// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// let x = "good Morning Good"
// console.log(x.replaceAll(/'good'/i,'bad')) //replaces the String at first occurance => i -> Case Sensitivity => g -> blobally

// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//  -- Objects --  \\

// let b = {
//     name : "Param",
//     rollno : 245102140022,
//     isTrainer : false,
//     param:function(){
//         console.log("hello")
//     },
//     mansi:{
//         name:"Manshi",
//         surname:"Pethani"
//     }
// } //Anonymos function -. without names //Anonymos function are not called but they are used in callback-. functions inside a functions

// console.log(b)
// console.log(b.mansi.name)
// b.mansi.name = "Param" //objects are reference datatypes -> value will be changed in source address itself
// console.log(b)
// console.log(b.mansi.name)

// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//unary Oprators
//a-- //--a
//a++ //++a

//  let a = 51
//  let b = a--
//  console.log(a)

// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

///ternary Operator -> (condition)?(true):(false)

// let c = 51
// c>50?console.log("grater"):console.log("smaller")

// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//Left Shift & Right Shift

// a=10 //by default jjs - var
// console.log(a<<3)// left sh;  ift devided by 2
// console.log(a>>3)// Right shift devided by 2 

// console.log(8^4)// [ | -> bitwise or ] [ & -> bitwise and ] [^ -> bitwise xor]
// console.log(~51)// ~ bitwise not -> add 1 and aa - //logical operators

// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// logical Operators

// &&, ||, !    

// console.log(true && false) //false
// console.log(false || false) //false

// let t= 10
// let u = 20
// console.log(!(t>u && t<u)) //true
// console.log(!(t>u || t<u)) //false

// Returning Function

// function add(a,b)
// {
//     return a+b //return -> functions ceases (ends)
// }

// function sub(a,b)
// {
//     return a-b
// }
// function mul(a,b)

// {
//     return a*b
// }
// function div(a,b)
// {
//     return a/b
// }
// console.log("Addition " + add(5,6) + " \nSubstraction " + sub(5,6) + " \nMultiplication " + mul(5,6) + " \Division " + div(5,6))

// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// Arrays In JavaScript

// let x = [1, false, "param", 20.5, 0.0025, {laptop:"acer",cpu:"i5"}]
// console.log(x)
// console.log(typeof(x))
// console.log(x[1])
// for(i=0 ; i < x.length ; i++)
// {
//     console.log(x[i])
// }

// let x  = [1,2,"abc",true,false]

// console.log(x)
// console.log(x.pop()) //remove the element from the last position
// console.log(x)
// console.log(x.shift()) //remove the element from thr first position and return the removed element
// console.log(x)
// console.log(x.unshift("Param")) //remove the element from first position and return the updated length
// console.log(x)

// splice(startindex,delete count, insert)
// delete x[2]
// console.log(x)
// console.log(x.splice(1,3))
// console.log(x)
// console.log(x.slice(1,2,1,0,"Param"))
// console.log(x)