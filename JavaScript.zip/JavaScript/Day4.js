// let a = [1,true,0,"Param",{name:"Param"},false]

// //for in loop -> print Array element and Array index
// for(let i in a)
// {
//     console.log(i + " " + a[i])
// }

// console.log(" ")
// console.log("For of Loop")

// //for of loop -> only print Array Element
// for(let i of a)
// {
//     console.log(i)
// }

// console.log(" ")
//For-Each Loop
//Where First position -> element -> return element of array
// Second position -> index -> return Index number Of array
// Third Position -> array -> array length time print array
// console.log(a.forEach(function(element, index, array){
//     console.log(element + " " + index + " " + array)
// }))

//Anonymous Function -> Nameless Functions -> used in Callback
//Callback -> function inside a function

// Exception Handling
//to avoid unexpected breakage of the program
//to maintain the flow of program

//Error in Js
    // 1) Syntax error
    // in the case of syntax error , the execution ceases
    // console.log("Hello")
    // console.log("js)

    // 2) Runtime Error
    // Runtime Error -> Reference errors
    // console.log("Hello")
    // console.log(x)
    // console.log("Hello Param")

    // 3) Logical Error
    // Output, No error, partial error, no output
    /// Output is not expected output
    // function add(a,b){
    //     console.log(a-b)
    // }
    // add(5,6)

    // 4) Try-Catch Block
    // try
    // {
    //     eval('console.log("Hello)') // eval() -> use For Identify Syntex Error


    // }
    // catch(err)
    // {
    //     console.log("Error is " + err + " \n\nPlease try again")
    // }
 

    // 5) custom Exception
    // try{
    //     let x = 1/0
    //     if(x == Infinity)
    //     {
    //         throw new error //creating Own exception
    //     }
    //     console.log(x)
    // }catch(err){
    //     console.log("Can't devided by 0")
    // }

    // const t = [1,2,3,4,5]
    // t.push(6)
    // t[3] = 25 //acces the Element in Index Level
    // console.log(t)

    // const car = {type : "Fail", model:"500",color:"white"};
    // car.color = "red"
    // car.owner = "Param"
    // console.log("Car Owner " + car.owner)

// console.log(Number(true))
// console.log(Number(false))
// console.log(Number("10"))
// console.log(Number(" 10"))
// console.log(Number("10 "))
// console.log(Number(" 10 "))
// console.log(Number(10.33))
// console.log(Number("10,33"))
// console.log(Number("10 33"))
// console.log(Number("param"))
// console.log(" ")
// console.log(" ")
// console.log(parseInt("-10"))
// console.log(parseInt("-10.33"))
// console.log(parseInt("10"))
// console.log(parseInt("10 20 30"))
// console.log(parseInt(10.33))
// console.log(parseInt("10 Years"))
// console.log(parseInt("Years 10"))
// console.log(" ")
// console.log(" ")
// console.log(parseFloat("-10"))
// console.log(parseFloat("-10.33"))
// console.log(parseFloat("10"))
// console.log(parseFloat("10 20 30"))
// console.log(parseFloat(10.33))
// console.log(parseFloat("10 Years"))
// console.log(parseFloat("Years 10"))

// const d = new Date()
// d.setFullYear(2025,4,24)
// console.log(d)

// d.setDate(d.getDate()+50)
// console.log(d)
// function cal()
// {
//     let month=document.getElementById("month")
//     switch(month)
//     {
//         case "jan":
//             console.log("31")
//             break
//         case "feb":
//             console.log("29")
//             break
//         case "march":
//                 console.log("31")
//                 break
//     }
// }

// "use strict"
// let x =10
// console.log(x)

// BOM //

// alert("Welcome to Day-4 Page")
// let a = prompt("Enter Name")
// let pass = prompt("Enter Password")

// if(a == "admin" && pass == "admin123")
// {
//     alert("Welcome Admin")
// }
// else
// {
//     confirm("Invalid Data")
// }

// let x = confirm("close Tab")

// if(x)
// {
//     window.close()
// }